package model

// 群组表
type Group struct {
	Id        int
	OUid      int
	Name      string
	CreatedAt int64
}
