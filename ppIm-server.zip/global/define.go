package global

type Data map[string]interface{}