package global

const SUCCESS  = 0
const FAIL 	   = -10000
const AUTHFAIL = -40001
const NOTFOUND = -40002
